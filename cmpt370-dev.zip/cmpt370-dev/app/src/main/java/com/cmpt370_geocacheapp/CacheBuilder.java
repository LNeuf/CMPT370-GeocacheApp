public interface CacheBuilder {
    public void buildCache(String name, String author, long cacheID);
}
