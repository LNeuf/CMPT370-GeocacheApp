package com.cmpt370_geocacheapp;

/**
 * Listener interface for Application model
 */
public interface ModelListener {
    void modelChanged();
}
