package com.cmpt370_geocacheapp;

/**
 * Listener interface for Interaction model
 */
public interface IModelListener {
    void iModelChanged();
}
